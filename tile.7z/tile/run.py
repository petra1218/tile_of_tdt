execfile( 'd:/code_my/python/tile/tile.py', {'a':'test'})
